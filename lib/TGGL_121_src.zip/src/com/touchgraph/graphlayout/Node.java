/*
 *  TouchGraph LLC. Apache-Style Software License
 *
 *
 *  Copyright (c) 2001-2002 Alexander Shapiro. All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  2. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  3. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by
 *  TouchGraph LLC (http://www.touchgraph.com/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  4. The names "TouchGraph" or "TouchGraph LLC" must not be used to endorse
 *  or promote products derived from this software without prior written
 *  permission.  For written permission, please contact
 *  alex@touchgraph.com
 *
 *  5. Products derived from this software may not be called "TouchGraph",
 *  nor may "TouchGraph" appear in their name, without prior written
 *  permission of alex@touchgraph.com.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL TOUCHGRAPH OR ITS CONTRIBUTORS BE
 *  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 *  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 *  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 *  BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 *  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 *  OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 *  EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *  ====================================================================
 *
 */
package com.touchgraph.graphlayout;
import java.awt.Composite;
import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.RenderingHints;
import java.awt.geom.Ellipse2D;
import java.awt.geom.AffineTransform;
import java.util.Iterator;
import java.util.Vector;

/**
 *  Node.
 *
 * @author     Alexander Shapiro
 * @author     Murray Altheim (2001-11-06; added support for round rects and
 *      alternate Node colors)
 * @version    1.21 $Id: Node.java,v 1.29 2002/04/01 05:52:15 x_ander Exp $
 */
public class Node {

    /**
     *  This Node's type is a Rectangle.
     */
    public final static int TYPE_RECTANGLE = 1;

    /**
     *  This Node's type is a Round Rectangle.
     */
    public final static int TYPE_ROUNDRECT = 2;

    /**
     *  This Node's type is an Ellipse.
     */
    public final static int TYPE_ELLIPSE = 3;

    /**
     *  This Node's type is a Circle.
     */
    public final static int TYPE_CIRCLE = 4;

    /**
     *  Description of the Field
     */
    public final static Font SMALL_TAG_FONT = new Font("Courier", Font.PLAIN, 9);

    // Variables that store default values for colors + fonts + node type
    /**
     *  Description of the Field
     */
    public static Color BACK_FIXED_COLOR = Color.red;
    /**
     *  Description of the Field
     */
    public static Color BACK_SELECT_COLOR = new Color(255, 224, 0);
    /**
     *  Description of the Field
     */
    //public static Color BACK_DEFAULT_COLOR = new Color(208, 96, 0);
    public static Color BACK_DEFAULT_COLOR = new Color(177, 177, 233);
    /**
     *  Description of the Field
     */
    public static Color BACK_HILIGHT_COLOR = Color.decode("#ffb200");
    // altheim: new

    /**
     *  Description of the Field
     */
    public static Color BORDER_DRAG_COLOR = Color.black;
    /**
     *  Description of the Field
     */
    public static Color BORDER_MOUSE_OVER_COLOR = new Color(160, 160, 160);
    /**
     *  Description of the Field
     */
    public static Color BORDER_INACTIVE_COLOR = Color.white;

    /**
     *  Description of the Field
     */
    public static Color TEXT_COLOR = Color.black;

    /**
     *  Description of the Field
     */
    public static Font TEXT_FONT = new Font("Courier", Font.PLAIN, 12);

    /**
     *  Description of the Field
     */
    public static int DEFAULT_TYPE = 1;

    /**
     *  an int indicating the Node type.
     *
     * @see    TYPE_RECTANGLE
     * @see    TYPE_ROUNDRECT
     * @see    TYPE_ELLIPSE
     */
    protected int typ = TYPE_RECTANGLE;
    private String id;

    /**
     *  Description of the Field
     */
    public double drawx;
    /**
     *  Description of the Field
     */
    public double drawy;

    /**
     *  Description of the Field
     */
    protected FontMetrics fontMetrics;
    /**
     *  Description of the Field
     */
    protected Font font;

    /**
     *  Description of the Field
     */
    protected String lbl;
    /**
     *  Description of the Field
     */
    protected Color backColor = BACK_DEFAULT_COLOR;
    /**
     *  Description of the Field
     */
    protected Color textColor = TEXT_COLOR;

    /**
     *  Description of the Field
     */
    public double x;
    /**
     *  Description of the Field
     */
    public double y;

    /**
     *  Description of the Field
     */
    protected double dx;
    //Used by layout
    /**
     *  Description of the Field
     */
    protected double dy;
    //Used by layout

    /**
     *  Description of the Field
     */
    protected boolean fixed;
    /**
     *  Description of the Field
     */
    protected int repulsion;
    //Used by layout

    /**
     *  Description of the Field
     */
    public boolean justMadeLocal = false;
    /**
     *  Description of the Field
     */
    public boolean markedForRemoval = false;

    /**
     *  Description of the Field
     */
    public int visibleEdgeCnt;
    //Should only be modified by graphelements.VisibleLocality
    /**
     *  Description of the Field
     */
    protected boolean visible;

    private Vector edges;


    /**
     *  Minimal constructor which will generate an ID value from Java's Date
     *  class. Defaults will be used for type and color. The label will be taken
     *  from the ID value.
     */
    public Node() {
        initialize(null);
        lbl = id;
    }


    /**
     *  Constructor with the required ID <tt>id</tt> , using defaults for type
     *  (rectangle), color (a static variable from TGPanel). The Node's label
     *  will be taken from the ID value.
     *
     * @param  id  Description of the Parameter
     */
    public Node(String id) {
        initialize(id);
        lbl = id;
    }


    /**
     *  Constructor with Strings for ID <tt>id</tt> and <tt>label</tt> , using
     *  defaults for type (rectangle) and color (a static variable from
     *  TGPanel). If the label is null, it will be taken from the ID value.
     *
     * @param  id     Description of the Parameter
     * @param  label  Description of the Parameter
     */
    public Node(String id, String label) {
        initialize(id);
        if (label == null) {
            lbl = id;
        } else {
            lbl = label;
        }
    }


    /**
     *  Constructor with a String ID <tt>id</tt> , an int <tt>type</tt> ,
     *  Background Color <tt>bgColor</tt> , and a String <tt>label</tt> . If the
     *  label is null, it will be taken from the ID value.
     *
     * @param  id     Description of the Parameter
     * @param  type   Description of the Parameter
     * @param  color  Description of the Parameter
     * @param  label  Description of the Parameter
     * @see           TYPE_RECTANGLE
     * @see           TYPE_ROUNDRECT
     */
    public Node(String id, int type, Color color, String label) {
        initialize(id);
        typ = type;
        backColor = color;
        if (label == null) {
            lbl = id;
        } else {
            lbl = label;
        }
    }


    /**
     *  Description of the Method
     *
     * @param  identifier  Description of the Parameter
     */
    private void initialize(String identifier) {
        this.id = identifier;
        edges = new Vector();
        x = Math.random() * 2 - 1;
        // If multiple nodes are added without repositioning,
        y = Math.random() * 2 - 1;
        // randomizing starting location causes them to spread out nicely.
        repulsion = 100;
        font = TEXT_FONT;
        fixed = false;
        typ = DEFAULT_TYPE;
        visibleEdgeCnt = 0;
        visible = false;
    }


    // setters and getters ...............

    /**
     *  Sets the nodeBackFixedColor attribute of the Node class
     *
     * @param  color  The new nodeBackFixedColor value
     */
    public static void setNodeBackFixedColor(Color color) {
        BACK_FIXED_COLOR = color;
    }


    /**
     *  Sets the nodeBackSelectColor attribute of the Node class
     *
     * @param  color  The new nodeBackSelectColor value
     */
    public static void setNodeBackSelectColor(Color color) {
        BACK_SELECT_COLOR = color;
    }


    /**
     *  Sets the nodeBackDefaultColor attribute of the Node class
     *
     * @param  color  The new nodeBackDefaultColor value
     */
    public static void setNodeBackDefaultColor(Color color) {
        BACK_DEFAULT_COLOR = color;
    }


    /**
     *  Sets the nodeBackHilightColor attribute of the Node class
     *
     * @param  color  The new nodeBackHilightColor value
     */
    public static void setNodeBackHilightColor(Color color) {
        BACK_HILIGHT_COLOR = color;
    }


    /**
     *  Sets the nodeBorderDragColor attribute of the Node class
     *
     * @param  color  The new nodeBorderDragColor value
     */
    public static void setNodeBorderDragColor(Color color) {
        BORDER_DRAG_COLOR = color;
    }


    /**
     *  Sets the nodeBorderMouseOverColor attribute of the Node class
     *
     * @param  color  The new nodeBorderMouseOverColor value
     */
    public static void setNodeBorderMouseOverColor(Color color) {
        BORDER_MOUSE_OVER_COLOR = color;
    }


    /**
     *  Sets the nodeBorderInactiveColor attribute of the Node class
     *
     * @param  color  The new nodeBorderInactiveColor value
     */
    public static void setNodeBorderInactiveColor(Color color) {
        BORDER_INACTIVE_COLOR = color;
    }


    /**
     *  Sets the nodeTextColor attribute of the Node class
     *
     * @param  color  The new nodeTextColor value
     */
    public static void setNodeTextColor(Color color) {
        TEXT_COLOR = color;
    }


    /**
     *  Sets the nodeTextFont attribute of the Node class
     *
     * @param  font  The new nodeTextFont value
     */
    public static void setNodeTextFont(Font font) {
        TEXT_FONT = font;
    }


    /**
     *  Sets the nodeType attribute of the Node class
     *
     * @param  type  The new nodeType value
     */
    public static void setNodeType(int type) {
        DEFAULT_TYPE = type;
    }


    /**
     *  Set the ID of this Node to the String <tt>id</tt> .
     *
     * @param  id  The new iD value
     */
    public void setID(String id) {
        this.id = id;
    }


    /**
     *  Return the ID of this Node as a String.
     *
     * @return    The iD value
     */
    public String getID() {
        return id;
    }


    /**
     *  Set the location of this Node provided the Point <tt>p</tt> .
     *
     * @param  p  The new location value
     */
    public void setLocation(Point p) {
        this.x = p.x;
        this.y = p.y;
    }


    /**
     *  Return the location of this Node as a Point.
     *
     * @return    The location value
     */
    public Point getLocation() {
        return new Point((int) x, (int) y);
    }


    /**
     *  Set the visibility of this Node to the boolean <tt>v</tt> .
     *
     * @param  v  The new visible value
     */
    public void setVisible(boolean v) {
        visible = v;
    }


    /**
     *  Return the visibility of this Node as a boolean.
     *
     * @return    The visible value
     */
    public boolean isVisible() {
        return visible;
    }


    /**
     *  Set the type of this Node to the int <tt>type</tt> .
     *
     * @param  type  The new type value
     * @see          TYPE_RECTANGLE
     * @see          TYPE_ROUNDRECT
     * @see          TYPE_ELLIPSE
     * @see          TYPE_CIRCLE
     */

    public void setType(int type) {
        typ = type;
    }


    /**
     *  Return the type of this Node as an int.
     *
     * @return    The type value
     * @see       TYPE_RECTANGLE
     * @see       TYPE_ROUNDRECT
     * @see       TYPE_ELLIPSE
     * @see       TYPE_CIRCLE
     */
    public int getType() {
        return typ;
    }


    /**
     *  Set the font of this Node to the Font <tt>font</tt> .
     *
     * @param  font  The new font value
     */
    public void setFont(Font font) {
        this.font = font;
    }


    /**
     *  Returns the font of this Node as a Font
     *
     * @return    The font value
     */
    public Font getFont() {
        return font;
    }


    /**
     *  Set the background color of this Node to the Color <tt>bgColor</tt> .
     *
     * @param  bgColor  The new backColor value
     */
    public void setBackColor(Color bgColor) {
        backColor = bgColor;
    }


    /**
     *  Return the background color of this Node as a Color.
     *
     * @return    The backColor value
     */
    public Color getBackColor() {
        return backColor;
    }


    /**
     *  Set the text color of this Node to the Color <tt>txtColor</tt> .
     *
     * @param  txtColor  The new textColor value
     */
    public void setTextColor(Color txtColor) {
        textColor = txtColor;
    }


    /**
     *  Return the text color of this Node as a Color.
     *
     * @return    The textColor value
     */
    public Color getTextColor() {
        return textColor;
    }


    /**
     *  Set the label of this Node to the String <tt>label</tt> .
     *
     * @param  label  The new label value
     */
    public void setLabel(String label) {
        lbl = label;
    }


    /**
     *  Return the label of this Node as a String.
     *
     * @return    The label value
     */
    public String getLabel() {
        return lbl;
    }


    /**
     *  Set the fixed status of this Node to the boolean <tt>fixed</tt> .
     *
     * @param  fixed  The new fixed value
     */
    public void setFixed(boolean fixed) {
        this.fixed = fixed;
    }


    /**
     *  Returns true if this Node is fixed (in place).
     *
     * @return    The fixed value
     */
    public boolean getFixed() {
        return fixed;
    }


    // ....

    /**
     *  Return the number of Edges in the cumulative Vector.
     *
     * @return        Description of the Return Value
     * @deprecated    this method has been replaced by the <tt>edgeCount()</tt>
     *      method.
     */
    public int edgeNum() {
        return edges.size();
    }


    /**
     *  Return the number of Edges in the cumulative Vector.
     *
     * @return    Description of the Return Value
     */
    public int edgeCount() {
        return edges.size();
    }


    /**
     *  Return an iterator over the Edges in the cumulative Vector, null if it
     *  is empty.
     *
     * @return    The edges value
     */
    public Iterator getEdges() {
        if (edges.size() == 0) {
            return null;
        } else {
            return edges.iterator();
        }
    }


    /**
     *  Returns the local Edge count.
     *
     * @return    Description of the Return Value
     */
    public int visibleEdgeCount() {
        return visibleEdgeCnt;
    }


    /**
     *  Return the Edge at int <tt>index</tt> .
     *
     * @param  index  Description of the Parameter
     * @return        Description of the Return Value
     */
    public Edge edgeAt(int index) {
        return (Edge) edges.elementAt(index);
    }


    /**
     *  Add the Edge <tt>edge</tt> to the graph.
     *
     * @param  edge  The feature to be added to the Edge attribute
     */
    public void addEdge(Edge edge) {
        if (edge == null) {
            return;
        }
        edges.addElement(edge);
    }


    /**
     *  Remove the Edge <tt>edge</tt> from the graph.
     *
     * @param  edge  Description of the Parameter
     */
    public void removeEdge(Edge edge) {
        edges.removeElement(edge);
    }


    /**
     *  Return the width of this Node.
     *
     * @return    The width value
     */
    public int getWidth() {
        if (fontMetrics != null && lbl != null) {
            return fontMetrics.stringWidth(lbl) + 12;
        } else {
            return 10;
        }
    }


    /**
     *  Return the height of this Node.
     *
     * @return    The height value
     */
    public int getHeight() {
        if (fontMetrics != null) {
            return fontMetrics.getHeight() + 6;
        } else {
            return 6;
        }
    }


    /**
     *  Returns true if this Node intersects Dimension <tt>d</tt> .
     *
     * @param  d  Description of the Parameter
     * @return    Description of the Return Value
     */
    public boolean intersects(Dimension d) {
        return (drawx > 0 && drawx < d.width && drawy > 0 && drawy < d.height);
    }


    /**
     *  Returns true if this Node contains the Point <tt>px,py</tt> .
     *
     * @param  px  Description of the Parameter
     * @param  py  Description of the Parameter
     * @return     Description of the Return Value
     */
    public boolean containsPoint(double px, double py) {
        return ((px > drawx - getWidth() / 2) && (px < drawx + getWidth() / 2)
                 && (py > drawy - getHeight() / 2) && (py < drawy + getHeight() / 2));
    }


    /**
     *  Returns true if this Node contains the Point <tt>p</tt> .
     *
     * @param  p  Description of the Parameter
     * @return    Description of the Return Value
     */
    public boolean containsPoint(Point p) {
        return ((p.x > drawx - getWidth() / 2) && (p.x < drawx + getWidth() / 2)
                 && (p.y > drawy - getHeight() / 2) && (p.y < drawy + getHeight() / 2));
    }


    /**
     *  Paints the Node.
     *
     * @param  g        Description of the Parameter
     * @param  tgPanel  Description of the Parameter
     */
    public void paint(Graphics g, TGPanel tgPanel) {
        if (!intersects(tgPanel.getSize())) {
            return;
        }
        paintNodeBody(g, tgPanel);

        if (visibleEdgeCount() < edgeCount()) {
            int ix = (int) drawx;
            int iy = (int) drawy;
            int h = getHeight();
            int w = getWidth();
            int tagX = ix + (w - 7) / 2 - 2 + w % 2;
            int tagY = iy - h / 2 - 2;
            char character;
            int hiddenEdgeCount = edgeCount() - visibleEdgeCount();
            character = (hiddenEdgeCount < 9) ? (char) ('0' + hiddenEdgeCount) : '*';
            paintSmallTag(g, tgPanel, tagX, tagY, Color.red, Color.white, character);
        }
    }


    /**
     *  Gets the paintBorderColor attribute of the Node object
     *
     * @param  tgPanel  Description of the Parameter
     * @return          The paintBorderColor value
     */
    public Color getPaintBorderColor(TGPanel tgPanel) {
        if (this == tgPanel.getDragNode()) {
            return BORDER_DRAG_COLOR;
        } else if (this == tgPanel.getMouseOverN()) {
            return BORDER_MOUSE_OVER_COLOR;
        } else {
            return BORDER_INACTIVE_COLOR;
        }
    }


    /**
     *  Gets the paintBackColor attribute of the Node object
     *
     * @param  tgPanel  Description of the Parameter
     * @return          The paintBackColor value
     */
    public Color getPaintBackColor(TGPanel tgPanel) {
        if (this == tgPanel.getSelect()) {
            return BACK_SELECT_COLOR;
        } else {
            if (fixed) {
                return BACK_FIXED_COLOR;
            }
            if (markedForRemoval) {
                return new Color(100, 60, 40);
            }
            if (justMadeLocal) {
                return new Color(255, 220, 200);
            }
            return backColor;
        }
    }


    /**
     *  Gets the paintTextColor attribute of the Node object
     *
     * @param  tgPanel  Description of the Parameter
     * @return          The paintTextColor value
     */
    public Color getPaintTextColor(TGPanel tgPanel) {
        return textColor;
    }


    /**
     *  Paints the background of the node, along with its label
     *
     * @param  g        Description of the Parameter
     * @param  tgPanel  Description of the Parameter
     */
    public void paintNodeBody(Graphics g, TGPanel tgPanel) {

        Graphics2D graphics = (Graphics2D) g;
        graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON);

        // Save the original composite.
        Composite oldComp = graphics.getComposite();
        // Create an AlphaComposite with 50% translucency.
        Composite alphaComp = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.65f);
        // Set the composite on the Graphics2D object.
        graphics.setComposite(alphaComp);

        graphics.setFont(font);
        fontMetrics = graphics.getFontMetrics();

        int ix = (int) drawx;
        int iy = (int) drawy;
        int h = getHeight() + 4;
        int w = getWidth() + 4;
        int r = h / 2 + 1;
        // arc radius

        Color borderCol = getPaintBorderColor(tgPanel);
        graphics.setColor(borderCol);

        if (typ == TYPE_ROUNDRECT) {
            graphics.fillRoundRect(ix - w / 2, iy - h / 2, w, h, r, r);
        } else if (typ == TYPE_ELLIPSE) {
            graphics.fillOval(ix - w / 2, iy - h / 2, w, h);
        } else if (typ == TYPE_CIRCLE) {
            // just use width for both dimensions
            graphics.fillOval(ix - w / 2, iy - w / 2, w, w);
        } else {
            // TYPE_RECTANGLE
            graphics.fillRect(ix - w / 2, iy - h / 2, w, h);
        }

        Color backCol = getPaintBackColor(tgPanel);
        graphics.setColor(backCol);

        if (typ == TYPE_ROUNDRECT) {
            graphics.fillRoundRect(ix - w / 2 + 2, iy - h / 2 + 2, w - 4, h - 4, r, r);
            graphics.setColor(new Color(0, 0, 0, 128));
            graphics.drawRoundRect(ix - w / 2 + 2, iy - h / 2 + 2, w - 3, h - 3, r, r);
        } else if (typ == TYPE_ELLIPSE) {
            graphics.fillOval(ix - w / 2 + 2, iy - h / 2 + 2, w - 4, h - 4);
            graphics.setColor(new Color(0, 0, 0, 128));
            graphics.drawOval(ix - w / 2 + 2, iy - h / 2 + 2, w - 3, h - 3);
            graphics.setColor(backCol);
        } else if (typ == TYPE_CIRCLE) {
            graphics.fillOval(ix - w / 2 + 2, iy - w / 2 + 2, w - 4, w - 4);
            graphics.setColor(new Color(0, 0, 0, 128));
            graphics.drawOval(ix - w / 2 + 2, iy - w / 2 + 2, w - 3, w - 3);
            graphics.setColor(backCol);
        } else {
            // TYPE_RECTANGLE
            graphics.fill3DRect(ix - w / 2 + 2, iy - h / 2 + 2, w - 4, h - 4, true);
        }
        Color textCol = getPaintTextColor(tgPanel);
        graphics.setColor(textCol);
        graphics.drawString(lbl, ix - fontMetrics.stringWidth(lbl) / 2, iy + fontMetrics.getDescent() + 1);

        // Restore the old composite.
        graphics.setComposite(oldComp);

    }


    /**
     *  Paints a tag with containing a character in a small font .
     *
     * @param  g          Description of the Parameter
     * @param  tgPanel    Description of the Parameter
     * @param  tagX       Description of the Parameter
     * @param  tagY       Description of the Parameter
     * @param  backCol    Description of the Parameter
     * @param  textCol    Description of the Parameter
     * @param  character  Description of the Parameter
     */
    public void paintSmallTag(Graphics g, TGPanel tgPanel, int tagX, int tagY,
            Color backCol, Color textCol, char character) {
        g.setColor(backCol);
        g.fillRect(tagX, tagY, 8, 8);
        g.setColor(textCol);
        g.setFont(SMALL_TAG_FONT);
        g.drawString("" + character, tagX + 2, tagY + 7);
    }

}

