/*
 *  TouchGraph LLC. Apache-Style Software License
 *
 *
 *  Copyright (c) 2001-2002 Alexander Shapiro. All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  2. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  3. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by
 *  TouchGraph LLC (http://www.touchgraph.com/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  4. The names "TouchGraph" or "TouchGraph LLC" must not be used to endorse
 *  or promote products derived from this software without prior written
 *  permission.  For written permission, please contact
 *  alex@touchgraph.com
 *
 *  5. Products derived from this software may not be called "TouchGraph",
 *  nor may "TouchGraph" appear in their name, without prior written
 *  permission of alex@touchgraph.com.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL TOUCHGRAPH OR ITS CONTRIBUTORS BE
 *  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 *  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 *  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 *  BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 *  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 *  OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 *  EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *  ====================================================================
 *
 */
package com.touchgraph.graphlayout;
import java.awt.BasicStroke;
import java.awt.Graphics2D;
import java.awt.Polygon;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Dimension;

/**
 *  Edge.
 *
 *@author     Alexander Shapiro
 *@version    1.21 $Id: Edge.java,v 1.28 2002/04/01 05:52:15 x_ander Exp $
 */
public class Edge {

    //public static Color DEFAULT_COLOR = Color.decode("#0000B0");
    /**
     *  Description of the Field
     */
    public static Color DEFAULT_COLOR = new Color(177, 177, 233);
    /**
     *  Description of the Field
     */
    public static Color MOUSE_OVER_COLOR = Color.pink;
    /**
     *  Description of the Field
     */
    public static int DEFAULT_LENGTH = 40;

    /**
     *  Description of the Field
     */
    public Node from;
    //Should be private, changing from effects "from" Node
    /**
     *  Description of the Field
     */
    public Node to;
    //Should be private, changing from effects "to" Node
    /**
     *  Description of the Field
     */
    protected Color col;
    /**
     *  Description of the Field
     */
    protected int length;
    /**
     *  Description of the Field
     */
    protected boolean visible;
    /**
     *  Description of the Field
     */
    protected String id = null;

    // ............

    /**
     *  Constructor with two Nodes and a length.
     *
     *@param  f    Description of the Parameter
     *@param  t    Description of the Parameter
     *@param  len  Description of the Parameter
     */
    public Edge(Node f, Node t, int len) {
        from = f;
        to = t;
        length = len;
        col = DEFAULT_COLOR;
        visible = false;
    }

    /**
     *  Constructor with two Nodes, which uses a default length.
     *
     *@param  f  Description of the Parameter
     *@param  t  Description of the Parameter
     */
    public Edge(Node f, Node t) {
        this(f, t, DEFAULT_LENGTH);
    }

    // setters and getters ...............

    /**
     *  Sets the edgeDefaultColor attribute of the Edge class
     *
     *@param  color  The new edgeDefaultColor value
     */
    public static void setEdgeDefaultColor(Color color) {
        DEFAULT_COLOR = color;
    }

    /**
     *  Sets the edgeMouseOverColor attribute of the Edge class
     *
     *@param  color  The new edgeMouseOverColor value
     */
    public static void setEdgeMouseOverColor(Color color) {
        MOUSE_OVER_COLOR = color;
    }

    /**
     *  Sets the edgeDefaultLength attribute of the Edge class
     *
     *@param  length  The new edgeDefaultLength value
     */
    public static void setEdgeDefaultLength(int length) {
        DEFAULT_LENGTH = length;
    }

    /**
     *  Returns the starting "from" node of this edge as Node.
     *
     *@return    The from value
     */
    public Node getFrom() {
        return from;
    }

    /**
     *  Returns the terminating "to" node of this edge as Node.
     *
     *@return    The to value
     */
    public Node getTo() {
        return to;
    }

    /**
     *  Returns the color of this edge as Color.
     *
     *@return    The color value
     */
    public Color getColor() {
        return col;
    }

    /**
     *  Set the color of this Edge to the Color <tt>color</tt> .
     *
     *@param  color  The new color value
     */
    public void setColor(Color color) {
        col = color;
    }

    /**
     *  Returns the ID of this Edge as a String.
     *
     *@return    The iD value
     */
    public String getID() {
        return id;
    }

    /**
     *  Set the ID of this Edge to the String <tt>id</tt> .
     *
     *@param  id  The new iD value
     */
    public void setID(String id) {
        this.id = id;
    }

    /**
     *  Returns the length of this Edge as a double.
     *
     *@return    The length value
     */
    public int getLength() {
        return length;
    }

    /**
     *  Set the length of this Edge to the int <tt>len</tt> .
     *
     *@param  len  The new length value
     */
    public void setLength(int len) {
        length = len;
    }

    /**
     *  Set the visibility of this Edge to the boolean <tt>v</tt> .
     *
     *@param  v  The new visible value
     */
    public void setVisible(boolean v) {
        visible = v;
    }

    /**
     *  Return the visibility of this Edge as a boolean.
     *
     *@return    The visible value
     */
    public boolean isVisible() {
        return visible;
    }

    /**
     *  Gets the otherEndpt attribute of the Edge object
     *
     *@param  n  Description of the Parameter
     *@return    The otherEndpt value
     */
    public Node getOtherEndpt(Node n) {
        //yields false results if Node n is not an endpoint
        if (to != n) {
            return to;
        } else {
            return from;
        }
    }

    /**
     *  Switches the endpoints of the edge
     */
    public void reverse() {
        Node temp = to;
        to = from;
        from = temp;
    }

    /**
     *  Description of the Method
     *
     *@param  d  Description of the Parameter
     *@return    Description of the Return Value
     */
    public boolean intersects(Dimension d) {
        int x1 = (int) from.drawx;
        int y1 = (int) from.drawy;
        int x2 = (int) to.drawx;
        int y2 = (int) to.drawy;

        return (((x1 > 0 || x2 > 0) && (x1 < d.width || x2 < d.width)) &&
                ((y1 > 0 || y2 > 0) && (y1 < d.height || y2 < d.height)));
    }

    /**
     *  Description of the Method
     *
     *@param  px  Description of the Parameter
     *@param  py  Description of the Parameter
     *@return     Description of the Return Value
     */
    public double distFromPoint(double px, double py) {
        double x1 = from.drawx;
        double y1 = from.drawy;
        double x2 = to.drawx;
        double y2 = to.drawy;

        if (px < Math.min(x1, x2) - 8 || px > Math.max(x1, x2) + 8 ||
                py < Math.min(y1, y2) - 8 || py > Math.max(y1, y2) + 8) {
            return 1000;
        }

        double dist = 1000;
        if (x1 - x2 != 0) {
            dist = Math.abs((y2 - y1) / (x2 - x1) * (px - x1) + (y1 - py));
        }
        if (y1 - y2 != 0) {
            dist = Math.min(dist, Math.abs((x2 - x1) / (y2 - y1) * (py - y1) + (x1 - px)));
        }

        return dist;
    }

    /**
     *  Description of the Method
     *
     *@param  px  Description of the Parameter
     *@param  py  Description of the Parameter
     *@return     Description of the Return Value
     */
    public boolean containsPoint(double px, double py) {
        return distFromPoint(px, py) < 10;
    }

    /**
     *  Description of the Method
     *
     *@param  g   Description of the Parameter
     *@param  x1  Description of the Parameter
     *@param  y1  Description of the Parameter
     *@param  x2  Description of the Parameter
     *@param  y2  Description of the Parameter
     *@param  c   Description of the Parameter
     */
    public static void paintArrow(Graphics g, int x1, int y1, int x2, int y2, Color c) {
        //Forget hyperbolic bending for now

        g.setColor(c);

        int x3 = x1;
        int y3 = y1;

        double dist = Math.sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
        if (dist > 10) {
            double adjustDistRatio = (dist - 10) / dist;
            x3 = (int) (x1 + (x2 - x1) * adjustDistRatio);
            y3 = (int) (y1 + (y2 - y1) * adjustDistRatio);
        }

        x3 = (int) ((x3 * 4 + x1) / 5.0);
        y3 = (int) ((y3 * 4 + y1) / 5.0);

        g.drawLine(x3, y3, x2, y2);
        g.drawLine(x1, y1, x3, y3);
        g.drawLine(x1 + 1, y1, x3, y3);
        g.drawLine(x1 + 2, y1, x3, y3);
        g.drawLine(x1 + 3, y1, x3, y3);
        g.drawLine(x1 + 4, y1, x3, y3);
        g.drawLine(x1 - 1, y1, x3, y3);
        g.drawLine(x1 - 2, y1, x3, y3);
        g.drawLine(x1 - 3, y1, x3, y3);
        g.drawLine(x1 - 4, y1, x3, y3);
        g.drawLine(x1, y1 + 1, x3, y3);
        g.drawLine(x1, y1 + 2, x3, y3);
        g.drawLine(x1, y1 + 3, x3, y3);
        g.drawLine(x1, y1 + 4, x3, y3);
        g.drawLine(x1, y1 - 1, x3, y3);
        g.drawLine(x1, y1 - 2, x3, y3);
        g.drawLine(x1, y1 - 3, x3, y3);
        g.drawLine(x1, y1 - 4, x3, y3);
    }

    /**
     *  Description of the Method
     *
     *@param  g        Description of the Parameter
     *@param  xCenter  Description of the Parameter
     *@param  yCenter  Description of the Parameter
     *@param  x        Description of the Parameter
     *@param  y        Description of the Parameter
     *@param  c        Description of the Parameter
     *@param  stroke   Description of the Parameter
     *@param  flip     Description of the Parameter
     */
    public static void paintArrow(Graphics g, int xCenter, int yCenter, int x, int y, Color c, float stroke, boolean flip) {
        Graphics2D g2d = (Graphics2D) g;
        g2d.setColor(c);
        if (flip) {
            int tmp = xCenter;
            xCenter = yCenter;
            yCenter = tmp;

            tmp = x;
            x = y;
            y = tmp;
        }

        double aDir = Math.atan2(xCenter - x, yCenter - y);
        g2d.drawLine(x, y, xCenter, yCenter);
        g2d.setStroke(new BasicStroke(1f));
        // make the arrow head solid even if dash pattern has been specified
        Polygon tmpPoly = new Polygon();
        int i1 = 8 + (int) (stroke * 2);
        int i2 = 4 + (int) stroke;
        // make the arrow head the same size regardless of the length length
        tmpPoly.addPoint(x, y);
        // arrow tip
        tmpPoly.addPoint(x + xCor(i1, aDir + .5), y + yCor(i1, aDir + .5));
        tmpPoly.addPoint(x + xCor(i2, aDir), y + yCor(i2, aDir));
        tmpPoly.addPoint(x + xCor(i1, aDir - .5), y + yCor(i1, aDir - .5));
        tmpPoly.addPoint(x, y);
        g2d.drawPolygon(tmpPoly);
        g2d.fillPolygon(tmpPoly);
    }


    /**
     *  Description of the Method
     *
     *@param  len  Description of the Parameter
     *@param  dir  Description of the Parameter
     *@return      Description of the Return Value
     */
    private static int yCor(int len, double dir) {
        return (int) (len * Math.cos(dir));
    }

    /**
     *  Description of the Method
     *
     *@param  len  Description of the Parameter
     *@param  dir  Description of the Parameter
     *@return      Description of the Return Value
     */
    private static int xCor(int len, double dir) {
        return (int) (len * Math.sin(dir));
    }


    /**
     *  Description of the Method
     *
     *@param  g        Description of the Parameter
     *@param  tgPanel  Description of the Parameter
     */
    public void paint(Graphics g, TGPanel tgPanel) {
        Color c = (tgPanel.getMouseOverE() == this) ? MOUSE_OVER_COLOR : col;

        int x1 = (int) from.drawx;
        int y1 = (int) from.drawy;
        int x2 = (int) to.drawx;
        int y2 = (int) to.drawy;

        // try and attach the arrow not to the center, but off-center in a predictible
        // manner, so that reciprocal edges do not overlap. If it's pointing up, move it
        // to the right. If it's down, move it to the left, if it's to the right, move it down
        // if it's to the left, move it up. (if it's diagonal, pick a direction). So, it's as if
        // the edge is attached to one arm of a small cross so that it always forms an angle in
        // the same direction (like a spring loaded budhist cross of sorts).
        // The real orientation of the coordinate system doesn't matter, obviously.

        int xdelta = x2 - x1;
        int ydelta = y2 - y1;

        int hdelta = xdelta;
        if (hdelta < 0) {
            hdelta = -hdelta;
        }
        int vdelta = ydelta;
        if (vdelta < 0) {
            vdelta = -vdelta;
        }
        if (vdelta > hdelta) {
            // rather vertical edge
            if (ydelta < 0) {
                // pointing down. move to left by 4.
                x1 -= 4;
                x2 -= 4;
            } else {
                // pointing up. move to the right.
                x1 += 4;
                x2 += 4;
            }
        } else {
            // rather horizontal edge
            if (xdelta < 0) {
                // pointing left. move up by 4
                y1 += 4;
                y2 += 4;
            } else {
                // pointing right. move down by 4
                y1 -= 4;
                y2 -= 4;
            }
        }

        if (intersects(tgPanel.getSize())) {
            paintArrow(g, x1, y1, x2, y2, c, 2, false);
        }
    }

}

